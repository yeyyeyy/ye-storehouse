import pygame
import random
import os,sys
from tkinter import messagebox

pygame.init()

标题 = pygame.display.set_caption("金币")
窗口 = pygame.display.set_mode((800,500),pygame.RESIZABLE)
窗口宽度 = 800
窗口高度 = 500
基准宽度 = 800
基准高度 = 500
clock = pygame.time.Clock()
font = pygame.font.SysFont("Microsoft YaHei", 24)
font_small = pygame.font.Font("C:\Windows\Fonts\msyh.ttc", 16)
金币 = 0
状态 = {'手动': 0,'自动': 0}
鼠标价格 = 50
鼠标等级 = 1
提示 = ""
字体颜色 = "white"
信息时长 = 0
自动点击 = {"状态": False,"点击间隔": 100,"等待点击": 0,"升级价格": 500}
暴击 = {'暴击率': 0,'暴击伤害': 5,'暴击率价格': 200,'暴击伤害价格': 700}
点击次数 = {"点击次数":5,"所需点击次数":5,"价格":10}
提示信息个数, 提示信息 = 0, {}
通关 = False
try:
    背景_白天 = pygame.image.load("_internal\\白天.png\\白天.png")
    背景_晚上 = pygame.image.load("_internal\\晚上.png\\晚上.png")
    背景_冬天 = pygame.image.load("_internal\\冬天.png\\冬天.png")
    背景_沙漠 = pygame.image.load("_internal\\沙漠.png\\沙漠.png")
    切换背景 = pygame.image.load("_internal\\切换.jpg\\切换.jpg")
    图标 = pygame.image.load("_internal\\图标.ico\\图标.ico")
    print("图片加载成功：文件夹目录")
except:
    try:
        临时目录 = sys._MEIPASS
        背景_白天 = os.path.join(临时目录, "白天.png\\白天.png")
        背景_晚上 = os.path.join(临时目录, "晚上.png\\晚上.png")
        背景_冬天 = os.path.join(临时目录, "冬天.png\\冬天.png")
        背景_沙漠 = os.path.join(临时目录, "沙漠.png\\沙漠.png")
        切换背景 = os.path.join(临时目录, "切换.jpg\\切换.jpg")
        图标 = os.path.join(临时目录, "图标.ico\\图标.ico")
        背景_白天 = pygame.image.load(背景_白天)
        背景_晚上 = pygame.image.load(背景_晚上)
        背景_冬天 = pygame.image.load(背景_冬天)
        背景_沙漠 = pygame.image.load(背景_沙漠)
        切换背景 = pygame.image.load(切换背景)
        图标 = pygame.image.load(图标)
        print("图片加载成功：单个exe程序")
    except:
        try:
            背景_白天 = pygame.image.load("E:\Python\\金币\\白天.png")
            背景_晚上 = pygame.image.load("E:\Python\\金币\\晚上.png")
            背景_冬天 = pygame.image.load("E:\Python\\金币\\冬天.png")
            背景_沙漠 = pygame.image.load("E:\Python\\金币\\沙漠.png")
            切换背景 = pygame.image.load("E:\Python\\金币\\切换.jpg")
            图标 = pygame.image.load("E:\Python\\金币\\图标.ico")
            print("图片加载成功：Python解析器")
        except:
            print("图片加载失败")
try:
    原始背景_白天 = 背景_白天.copy()
    原始背景_晚上 = 背景_晚上.copy()
    原始背景_冬天 = 背景_冬天.copy()
    原始背景_沙漠 = 背景_沙漠.copy()
    原始切换背景 = 切换背景.copy()
    背景_白天 = pygame.transform.scale(原始背景_白天, (800, 500))
    背景_晚上 = pygame.transform.scale(原始背景_晚上, (800, 500))
    背景_冬天 = pygame.transform.scale(原始背景_冬天, (800, 500))
    背景_沙漠 = pygame.transform.scale(原始背景_沙漠, (800, 500))
    切换背景 = pygame.transform.scale(原始切换背景, (30, 30))
    pygame.display.set_icon(图标)
except:
    pass
背景状态 = 0

def 更新布局():
    global 窗口宽度, 窗口高度, font, font_small
    window_size = pygame.display.get_surface().get_size()
    窗口宽度 = window_size[0]
    窗口高度 = window_size[1]
    字体大小 = max(16, int(24 * 窗口宽度 / 基准宽度))
    小字体大小 = max(12, int(16 * 窗口宽度 / 基准宽度))
    font = pygame.font.SysFont("Microsoft YaHei", 字体大小)
    font_small = pygame.font.SysFont("Microsoft YaHei", 小字体大小)

def 点击(方式):
    global 暴击,暴击设置,信息时长,提示,字体颜色,金币,鼠标等级,状态,自动点击状态,点击次数
    点击次数["点击次数"] -= 1
    if 点击次数["点击次数"] <= 0:
        点击次数["点击次数"] = 点击次数["所需点击次数"]
        if 暴击["暴击率"] > 0:
            if random.random() * 100 < 暴击["暴击率"]:
                金币 += 暴击["暴击伤害"]
                信息时长 = 20
                提示 = "暴击!"
                字体颜色 = "#A51F7F"
        金币 += 鼠标等级
    if 方式 == 0:
        状态['手动'] = 5
    elif 方式 == 1:
        状态['自动'] = 5
def 切换背景函数():
    global 背景状态
    背景状态 += 1
    if 背景状态 >= 4:
        背景状态 = 0
def 提示信息函数():
    global 提示, 字体颜色, 窗口, 提示信息列表, 信息时长
    if '提示信息列表' not in globals():
        提示信息列表 = []
    if 提示:
        提示文本 = f"{提示}"
        已存在 = False
        for 提示数据 in 提示信息列表:
            if 提示数据.get("文本内容") == 提示文本:
                已存在 = True
                提示数据["时间"] = 信息时长
                break
        if not 已存在:
            新提示 = {
                "信息": font_small.render(提示文本, True, 字体颜色),
                "时间": 信息时长,
                "x": random.randint(70, 130),
                "y": 250 + len(提示信息列表) * 30,
                "文本内容": 提示文本
            }
            if 新提示["y"] > 550:
                新提示["y"] = 250
            
            提示信息列表.append(新提示)
    i = 0
    while i < len(提示信息列表):
        提示数据 = 提示信息列表[i]
        窗口.blit(提示数据["信息"], (提示数据["x"], 提示数据["y"]))
        提示数据["时间"] -= 1
        if 提示数据["时间"] <= 0:
            提示信息列表.pop(i)
        else:
            i += 1


运行状态 = True
while 运行状态:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            运行状态 = False
        if event.type == pygame.VIDEORESIZE:
            width, height = event.w, event.h
            窗口 = pygame.display.set_mode((width, height), pygame.RESIZABLE)
            背景_白天 = pygame.transform.scale(原始背景_白天, (width, height))
            背景_晚上 = pygame.transform.scale(原始背景_晚上, (width, height))
            背景_冬天 = pygame.transform.scale(原始背景_冬天, (width, height))
            背景_沙漠 = pygame.transform.scale(原始背景_沙漠, (width, height))
            切换背景 = pygame.transform.scale(原始切换背景, (int(30 * width/基准宽度), int(30 * height/基准高度)))
            更新布局()
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                鼠标 = pygame.mouse.get_pos()
                if 点击按钮X1 <= 鼠标[0] <= 点击按钮X2 and 点击按钮Y1 <= 鼠标[1] <= 点击按钮Y2:
                    点击(0)
                elif 商店起始X <= 鼠标[0] <= 商店结束X and 商店起始Y <= 鼠标[1] <= 商店起始Y + 按钮高度:
                    if 金币 >= 鼠标价格:
                        金币 -= 鼠标价格
                        鼠标等级 += random.randint(1,4)
                        鼠标价格 += random.randint(95,round(鼠标价格 * 1.5 + random.randint(20,80)))
                        if random.random() <= 0.8:
                            点击次数["所需点击次数"] += random.randint(0,3)
                        信息时长 = 60
                        提示 = "成功升级鼠标！"
                        字体颜色 = "#0A8F3B"
                    else:
                        信息时长 = 60
                        提示 = "你没有足够的金币！"
                        字体颜色 = "red"
                elif 商店起始X <= 鼠标[0] <= 商店结束X and 商店起始Y + 按钮高度 + 按钮间距 <= 鼠标[1] <= 商店起始Y + 按钮高度 * 2 + 按钮间距:
                    if 暴击["暴击率"] >= 100:
                        信息时长 = 60
                        提示 = "暴击率已满级~"
                        字体颜色 = "#531BBD"
                    else:
                        if 金币 >= 暴击["暴击率价格"]:
                            金币 -= 暴击["暴击率价格"]
                            暴击["暴击率"] += random.randint(5,20)
                            暴击["暴击率价格"] += random.randint(200,500)
                            信息时长 = 60
                            提示 = "成功升级暴击率！"
                            字体颜色 = "#0A8F3B"
                        else:
                            信息时长 = 60
                            提示 = "你没有足够的金币！"
                            字体颜色 = "red"
                elif 商店起始X <= 鼠标[0] <= 商店结束X and 商店起始Y + 按钮高度 * 2 + 按钮间距 * 2 <= 鼠标[1] <= 商店起始Y + 按钮高度 * 3 + 按钮间距 * 2:
                    if 自动点击["点击间隔"] <= 0:
                        信息时长 = 60
                        提示 = "自动点击已满级~"
                        字体颜色 = "#531BBD"
                        通关 = False
                    else:
                        if 金币 >= 自动点击["升级价格"]:
                            金币 -= 自动点击["升级价格"]
                            if 自动点击["状态"] == False:
                                自动点击["状态"] = True
                            else:
                                自动点击["点击间隔"] -= random.randint(5,10)
                                if 自动点击["点击间隔"] < 0:
                                    自动点击["点击间隔"] = 0
                            自动点击["升级价格"] += random.randint(200,500)
                            信息时长 = 60
                            提示 = "成功升级自动点击！"
                            字体颜色 = "#0A8F3B"
                        else:
                            信息时长 = 60
                            提示 = "你没有足够的金币！"
                            字体颜色 = "red"
                elif 商店起始X <= 鼠标[0] <= 商店结束X and 商店起始Y + 按钮高度 * 3 + 按钮间距 * 3 <= 鼠标[1] <= 商店起始Y + 按钮高度 * 4 + 按钮间距 * 3:
                    if 金币 >= 暴击["暴击伤害价格"]:
                        金币 -= 暴击["暴击伤害价格"]
                        暴击["暴击伤害"] += random.randint(round(鼠标等级 / 2),round(鼠标等级 * 1.3))
                        暴击["暴击伤害价格"] += random.randint(250,700)
                        信息时长 = 60
                        提示 = "成功升级暴击伤害！"
                        字体颜色 = "#0A8F3B"
                    else:
                        信息时长 = 60
                        提示 = "你没有足够的金币！"
                        字体颜色 = "red"
                elif 商店起始X <= 鼠标[0] <= 商店结束X and 商店起始Y + 按钮高度 * 4 + 按钮间距 * 4 <= 鼠标[1] <= 商店起始Y + 按钮高度 * 5 + 按钮间距 * 4:
                    if 点击次数["所需点击次数"] <= 1:
                        信息时长 = 60
                        提示 = "矿石等级已满级~"
                        字体颜色 = "#531BBD"
                    elif 金币 >= 点击次数["价格"]:
                        金币 -= 点击次数["价格"]
                        点击次数["所需点击次数"] -= random.randint(1,2)
                        if 点击次数["所需点击次数"] <= 0:
                            点击次数["所需点击次数"] = 1
                        if 点击次数["点击次数"] > 点击次数["所需点击次数"]:
                            点击次数["点击次数"] = 点击次数["所需点击次数"]
                        点击次数["价格"] += random.randint(鼠标等级 - random.randint(2,5),鼠标等级 + random.randint(7,15))
                        信息时长 = 60
                        提示 = "成功升级矿石！"
                        字体颜色 = "#0A8F3B"
                    else:
                        信息时长 = 60
                        提示 = "你没有足够的金币！"
                        字体颜色 = "red"
                elif 切换按钮X1 <= 鼠标[0] <= 切换按钮X2 and 0 <= 鼠标[1] <= 切换按钮Y2:
                    切换背景函数()
    if 自动点击["点击间隔"] <= 0 and 通关 == False:
        回答 = messagebox.askyesno("胜利","您已通关本游戏，是否退出？")
        if 回答 == True:
            sys.exit()
        else:
            通关 = True

    更新布局()
    缩放X = 窗口宽度 / 基准宽度
    缩放Y = 窗口高度 / 基准高度
    点击按钮X1 = int(360 * 缩放X)
    点击按钮X2 = int(410 * 缩放X)
    点击按钮Y1 = int(210 * 缩放Y)
    点击按钮Y2 = int(260 * 缩放Y)
    商店起始X = int(650 * 缩放X)
    商店结束X = int(800 * 缩放X)
    按钮高度 = int(50 * 缩放Y)
    按钮间距 = int(5 * 缩放Y)
    商店起始Y = int(100 * 缩放Y)
    切换按钮X1 = int(770 * 缩放X)
    切换按钮X2 = int(800 * 缩放X)
    切换按钮Y2 = int(30 * 缩放Y)

    窗口.fill((255,255,255))
    try:
        if 背景状态 == 0:
            窗口.blit(背景_白天,(0,0))
        elif 背景状态 == 1:
            窗口.blit(背景_晚上,(0,0))
        elif 背景状态 == 2:
            窗口.blit(背景_冬天,(0,0))
        elif 背景状态 == 3:
            窗口.blit(背景_沙漠,(0,0))
        窗口.blit(切换背景,(int(770*缩放X), 0))
    except Exception as e:
        pass
    自动点击X = int(460 * 缩放X)
    自动点击Y = int(210 * 缩放Y)
    自动点击大小 = int(50 * 缩放X)
    进度条Y = int(180 * 缩放Y)
    进度条高度 = int(15 * 缩放Y)
    if 自动点击["状态"] == True:
        if not 自动点击["点击间隔"] < 1:
            if 自动点击["等待点击"] <= 0:
                点击(1)
                自动点击["等待点击"] = 自动点击["点击间隔"]
            自动点击["等待点击"] -= 1
        else:
            点击(1)
        if 状态["自动"] > 0:
            pygame.draw.rect(窗口,"#9CEB52",(自动点击X, 自动点击Y, 自动点击大小, 自动点击大小),0)
            状态["自动"] -= 1
        elif 状态["自动"] == 0:
            pygame.draw.rect(窗口,"#28C049",(自动点击X, 自动点击Y, 自动点击大小, 自动点击大小),0)
        pygame.draw.rect(窗口,"#EBE952",(int(440*缩放X), 进度条Y, int(自动点击["等待点击"]*缩放X), 进度条高度),0)
        pygame.draw.rect(窗口,"#0FA78E",(int(440*缩放X), 进度条Y, int(自动点击["点击间隔"]*缩放X), 进度条高度),1)

    if 点击次数["所需点击次数"] > 1:
        进度条宽度 = int(95 * 缩放X)
        pygame.draw.rect(窗口,"#71EB52",(int(340*缩放X), 进度条Y, int(点击次数["点击次数"]/点击次数["所需点击次数"]*进度条宽度), 进度条高度),0)
        pygame.draw.rect(窗口,"#4EA733",(int(340*缩放X), 进度条Y, 进度条宽度, 进度条高度),1)
    if 状态["手动"] > 0:
        pygame.draw.rect(窗口,"cyan",(点击按钮X1, 点击按钮Y1, 点击按钮X2-点击按钮X1, 点击按钮Y2-点击按钮Y1),0)
        状态["手动"] -= 1
    elif 状态["手动"] == 0:
        pygame.draw.rect(窗口,"blue",(点击按钮X1, 点击按钮Y1, 点击按钮X2-点击按钮X1, 点击按钮Y2-点击按钮Y1),0)
    pygame.draw.rect(窗口,"#2565A5",(int(680*缩放X), int(60*缩放Y), int(90*缩放X), int(35*缩放Y)),0)
    for i in range(5):
        pygame.draw.rect(窗口,"#F5862D",(商店起始X, 商店起始Y + i*(按钮高度+按钮间距), 商店结束X-商店起始X, 按钮高度),0)

    gold_text = font.render(f"金币：{金币}", True, (255, 215, 0))
    鼠标等级显示 = font.render(f"鼠标等级：{鼠标等级}", True, "#0078D4")
    暴击率显示 = font.render(f"暴击率：{暴击['暴击率']}%", True, "#FA3A36")
    自动点击显示 = font.render(f"自动点击：{100 - 自动点击['点击间隔']}/100", True, "#A465D6")
    暴击伤害显示 = font.render(f"暴击伤害：{暴击['暴击伤害']+鼠标等级}", True, "#7665D6")
    矿石等级显示 = font.render(f"矿石等级：{点击次数['所需点击次数']}", True, "#656DD6")
    商店显示 = font.render(f"商店", True, "#F7C10F")
    if 金币 >= 鼠标价格:
        升级鼠标 = font_small.render("鼠标升级：", True, "#03DC6C")
        升级鼠标价格 = font_small.render(f"{鼠标价格}", True, "#03DC6C")
    else:
        升级鼠标 = font_small.render("鼠标升级：", True, "red")
        升级鼠标价格 = font_small.render(f"{鼠标价格}", True, "red")
    if 暴击["暴击率"] >= 100:
        升级暴击 = font_small.render("暴击率升级：", True, "#531BBD")
        升级暴击价格 = font_small.render("max", True, "#961EB4")
    elif 金币 >= 暴击["暴击率价格"]:
        升级暴击 = font_small.render("暴击率升级：", True, "#03DC6C")
        升级暴击价格 = font_small.render(f"{暴击['暴击率价格']}", True, "#03DC6C")
    else:
        升级暴击 = font_small.render("暴击率升级：", True, "red")
        升级暴击价格 = font_small.render(f"{暴击['暴击率价格']}", True, "red")
    if 自动点击["点击间隔"] <= 0:
        升级自动点击 = font_small.render("自动点击 点击通关", True, "#531BBD")
        升级自动点击价格 = font_small.render("max", True, "#961EB4")
    elif 金币 >= 自动点击["升级价格"]:
        升级自动点击 = font_small.render("自动点击升级：", True, "#03DC6C")
        升级自动点击价格 = font_small.render(f"{自动点击['升级价格']}", True, "#03DC6C")
    else:
        升级自动点击 = font_small.render("自动点击升级：", True, "red")
        升级自动点击价格 = font_small.render(f"{自动点击['升级价格']}", True, "red")
    if 金币 >= 暴击["暴击伤害价格"]:
        升级暴击伤害 = font_small.render("暴击伤害升级：", True, "#03DC6C")
        升级暴击伤害价格 = font_small.render(f"{暴击['暴击伤害价格']}", True, "#03DC6C")
    else:
        升级暴击伤害 = font_small.render("暴击伤害升级：", True, "red")
        升级暴击伤害价格 = font_small.render(f"{暴击['暴击伤害价格']}", True, "red")
    if 点击次数["所需点击次数"] <= 1:
        升级点击 = font_small.render("矿石升级：", True, "#531BBD")
        升级点击价格 = font_small.render("max", True, "#961EB4")
    elif 金币 >= 点击次数["价格"]:
        升级点击 = font_small.render("矿石升级：", True, "#03DC6C")
        升级点击价格 = font_small.render(f"{点击次数['价格']}", True, "#03DC6C")
    else:
        升级点击 = font_small.render("矿石升级：", True, "red")
        升级点击价格 = font_small.render(f"{点击次数['价格']}", True, "red")
    提示信息函数()

    行间距 = int(25 * 缩放Y)
    窗口.blit(gold_text, (int(10*缩放X), int(10*缩放Y)))
    窗口.blit(鼠标等级显示, (int(10*缩放X), int(10*缩放Y) + 行间距))
    窗口.blit(暴击率显示, (int(10*缩放X), int(10*缩放Y) + 行间距*2))
    窗口.blit(自动点击显示, (int(10*缩放X), int(10*缩放Y) + 行间距*3))
    窗口.blit(暴击伤害显示, (int(10*缩放X), int(10*缩放Y) + 行间距*4))
    窗口.blit(矿石等级显示, (int(10*缩放X), int(10*缩放Y) + 行间距*5))


    窗口.blit(商店显示, (int(700*缩放X), int(60*缩放Y)))
    商店文字X = int(660 * 缩放X)
    商店文字行高 = int(15 * 缩放Y)
    窗口.blit(升级鼠标, (商店文字X, 商店起始Y + int(10*缩放Y)))
    窗口.blit(升级鼠标价格, (商店文字X, 商店起始Y + int(10*缩放Y) + 商店文字行高))
    窗口.blit(升级暴击, (商店文字X, 商店起始Y + 按钮高度 + 按钮间距 + int(10*缩放Y)))
    窗口.blit(升级暴击价格, (商店文字X, 商店起始Y + 按钮高度 + 按钮间距 + int(10*缩放Y) + 商店文字行高))
    窗口.blit(升级自动点击, (商店文字X, 商店起始Y + (按钮高度+按钮间距)*2 + int(10*缩放Y)))
    窗口.blit(升级自动点击价格, (商店文字X, 商店起始Y + (按钮高度+按钮间距)*2 + int(10*缩放Y) + 商店文字行高))
    窗口.blit(升级暴击伤害, (商店文字X, 商店起始Y + (按钮高度+按钮间距)*3 + int(10*缩放Y)))
    窗口.blit(升级暴击伤害价格, (商店文字X, 商店起始Y + (按钮高度+按钮间距)*3 + int(10*缩放Y) + 商店文字行高))
    窗口.blit(升级点击, (商店文字X, 商店起始Y + (按钮高度+按钮间距)*4 + int(10*缩放Y)))
    窗口.blit(升级点击价格, (商店文字X, 商店起始Y + (按钮高度+按钮间距)*4 + int(10*缩放Y) + 商店文字行高))

    if 信息时长 > 0:
        信息时长 -= 1
    else:
        提示, 字体颜色 = "", "white"
    if 暴击["暴击率"] > 100:
        暴击["暴击率"] = 100
    pygame.display.flip()
    clock.tick(120)

pygame.quit()